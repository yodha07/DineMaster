﻿namespace DineMasterApi.DTO
{
    public class GenerateBillRequestDto
    {
        public string PaymentMethod { get; set; }
    }
}
