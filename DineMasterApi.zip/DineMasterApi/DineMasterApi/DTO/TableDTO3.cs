﻿namespace DineMasterApi.DTO
{
    public class TableDTO3
    {
        public int TableId { get; set; }
        public string Name { get; set; }
        public int Capacity { get; set; }
        public string Status { get; set; }
        public string? ModifiedBy { get; set; }
    }
}
