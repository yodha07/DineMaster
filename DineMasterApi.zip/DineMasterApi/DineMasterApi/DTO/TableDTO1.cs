﻿namespace DineMasterApi.DTO
{
    public class TableDTO1
    {
        public string Name { get; set; }
        public int Capacity { get; set; }
        public string Status { get; set; }
        public string CreatedBy { get; set; }
    }
}
