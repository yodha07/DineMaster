﻿namespace DineMasterApi.DTO
{
    public class OtpVerifyDTO
    {
        public int OrderId { get; set; }
        public string Otp { get; set; }
    
}
}
