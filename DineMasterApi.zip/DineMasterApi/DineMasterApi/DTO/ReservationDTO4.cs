﻿namespace DineMasterApi.DTO
{
    public class ReservationDTO4
    {
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int GuestsCount { get; set; }
    }
}
